# -*- coding: utf-8 -*-
"""
Created on Tue May 26 13:30:35 2015

@author: Wasit
"""

import pandas as pd
broken_df = pd.read_csv('CS_table_No1.csv',delimiter=";")